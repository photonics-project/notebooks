
def test_import_fonttools():
    import fontTools
    